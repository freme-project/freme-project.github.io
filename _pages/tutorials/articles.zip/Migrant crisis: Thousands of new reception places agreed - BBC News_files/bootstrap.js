define([
    'config',
    'module/bootstrappedJquery',
    'module/globalPubsub',
], function(
    config,
    bootstrappedJquery,
    globalPubsub
) {

    var news = {
        pubsub: globalPubsub,
        $: bootstrappedJquery,
        config: config,
        window: window
    };

    return news;
});
