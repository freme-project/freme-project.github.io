define([
    'jquery'
], function(
    jquery
) {
    jquery.ajaxSetup({ cache: true });

    return jquery;
});
