define([
    'module/bootstrappedJquery',
    'vendor/events/pubsub'
], function(
    bootstrappedJquery
) {
    return bootstrappedJquery;
});
